create function textanycat(text, anynonarray) returns text
    stable
    strict
    parallel safe
    cost 1
    language sql
as
$$select $1 operator(pg_catalog.||) $2::pg_catalog.text$$;

comment on function textanycat(text, anynonarray) is 'implementation of || operator';

alter function textanycat(text, anynonarray) owner to postgres;

